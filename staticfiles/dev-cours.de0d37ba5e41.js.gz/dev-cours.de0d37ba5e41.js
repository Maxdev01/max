$(document).ready(function(){
    $('#first').click(function(){
        $('.hide').toggle();
    });

  /* $('#lesson1').click(function() {
       $('#less1').show();
       $('#less2').remove();
   });

   $('#lesson2').click(function() {
       $('less1').hide();
       $('#less2').show();
   }); */
   $('#first-btn').click(function() {
        $('#gch').toggle();
   });
   
   $('#deuxieme').click(function() {
        $('.hiden').toggle();
   });
   
   $('#four-time').click(function() {
      $('.cacher').toggle();
   });

   $('#five-time').click(function(){
       $('.cacher2').toggle();
   });

   $('#six-time').click(function(){
       $('.cacher3').toggle();
   });

   $('#seven-time').click(function(){
       $('.cacher4').toggle();
   });

   $('#heigt-time').click(function(){
       $('.cacher5').toggle();
   });
  
});


