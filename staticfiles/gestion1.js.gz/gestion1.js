$(document).ready(function(){
    $('#dos').click(function(){
        $('.none1').toggle();
    });
});